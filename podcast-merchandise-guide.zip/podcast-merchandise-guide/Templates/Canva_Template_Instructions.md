# How to Create Merch Designs in Canva

## Step 1: Set Up Canva
- Go to canva.com
- Create free account

## Step 2: Canvas Dimensions
| Product | Size (px) |
|---------|-----------|
| T-shirt front | 4500 × 5400 |
| Mug wrap | 4500 × 2700 |
| Sticker | 3000 × 3000 |
| Hoodie | 6000 × 6000 |

## Step 3: Design
1. Upload your podcast logo
2. Use brand colors
3. Keep text minimal (2-3 words)
4. Use transparent background (PNG)

## Step 4: Upload to POD Platform
1. Go to Printful/Printify
2. Select product
3. Upload design
4. Use mockup generator
5. Publish

## Free Resources:
- Canva (free templates)
- Remove.bg (background remover)
- Coolors.co (color palettes)
- FontPair.co (font combinations)
