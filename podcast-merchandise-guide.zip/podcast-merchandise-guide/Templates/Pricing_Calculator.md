# Merchandise Pricing Calculator

## Copy to Google Sheets

====================================
PRODUCT: ____________________
BASE COST: $________ (from POD platform)
SHIPPING COST: $________
TOTAL COST: $________

## PRICING OPTIONS:

Option 1 (2x markup)
Retail Price: $________ (Cost × 2)
Profit per item: $________
100 sales profit: $________

Option 2 (2.5x markup)
Retail Price: $________ (Cost × 2.5)
Profit per item: $________
100 sales profit: $________

Option 3 (3x markup - premium)
Retail Price: $________ (Cost × 3)
Profit per item: $________
100 sales profit: $________

## BUNDLE PRICING:
1 item: $________
3 items (10% off): $________
5 items (15% off): $________

## BREAK EVEN:
Total setup cost: $________
Profit per item: $________
Items to break even: ________ units
====================================
