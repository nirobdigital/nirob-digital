# Podcast Merch Design Brief Template

## Basic Information
**Podcast Name:** ____________________
**Designer Name:** ____________________
**Date:** ____________________
**Deadline:** ____________________

## Audience Details
**Target Age:** ____________________
**Style Preference:** ____________________
**Colors they love:** ____________________

## Design Requirements
**Product Type:** ____________________
**Colors in Design:** ____________________
**Text to include:** ____________________
**Font preference:** ____________________

## Inspiration
**Link to examples:** ____________________
**What to avoid:** ____________________
**Must-have elements:** ____________________

## Approval Process
**Round 1 review by:** ____________________
**Final sign-off by:** ____________________
