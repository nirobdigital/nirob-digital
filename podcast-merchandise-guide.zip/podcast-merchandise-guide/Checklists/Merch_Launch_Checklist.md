# 4-Week Merch Launch Checklist

## 4 Weeks Before
- [ ] Choose 3-5 merch products
- [ ] Select print-on-demand platform
- [ ] Create design brief
- [ ] Order samples for photography

## 3 Weeks Before
- [ ] Receive and quality check samples
- [ ] Photograph merch
- [ ] Create launch landing page
- [ ] Set up store

## 2 Weeks Before
- [ ] Collect email waitlist
- [ ] Create 3 teaser posts
- [ ] Record unboxing video
- [ ] Set discount codes

## 1 Week Before
- [ ] Post daily countdown
- [ ] Share behind-the-scenes
- [ ] Test checkout process

## Launch Day
- [ ] Send email to waitlist first
- [ ] Post launch announcement
- [ ] Track first hour sales

## Week After Launch
- [ ] Announce first milestone
- [ ] Share customer photos
- [ ] Send thank you email
