# Podcast Merchandise Planning & Design Guide
## Complete System for Selling Merch with Zero Inventory

### Best Merch Products for Podcasters

| Product | Profit Margin | Best For |
|---------|---------------|----------|
| Stickers | 70-80% | Entry level, giveaways |
| T-shirts | 40-50% | Classic, high demand |
| Hoodies | 45-55% | Premium, cold seasons |
| Mugs | 50-60% | Everyday use |
| Tote bags | 40-50% | Eco-friendly |
| Phone cases | 35-45% | Tech audience |

### Print-on-Demand Platforms

| Platform | Best For | Shipping |
|----------|----------|----------|
| Printful | Quality & variety | Worldwide |
| Printify | Lower prices | Worldwide |
| Redbubble | Built-in marketplace | Worldwide |
| Teespring | YouTube creators | Worldwide |

### Pricing Formula
**Retail Price = (Base Cost × 2) + Shipping**

Example:
- Base cost: $10 (shirt + printing)
- ×2 markup = $20
- Shipping: $5
- Total to customer: $25
- Your profit: $10 per shirt

### 4-Week Launch Strategy
- Week 1: Tease & poll audience
- Week 2: Share design sketches
- Week 3: Pre-order & waitlist
- Week 4: Launch & fulfill
