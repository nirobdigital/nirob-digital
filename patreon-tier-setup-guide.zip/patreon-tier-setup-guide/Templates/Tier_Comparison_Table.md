# Tier Comparison Table Template

## Copy and paste into Canva or Google Docs

============================================
| Tier | Supporter | Insider | Superfan |
|------|-----------|---------|----------|
| Price | $3/month | $8/month | $15/month |
| Early Access | ✓ | ✓ | ✓ |
| Ad-Free Feed | - | ✓ | ✓ |
| BTS Content | - | ✓ | ✓ |
| Discord Role | - | ✓ | ✓ |
| Monthly Q&A | - | - | ✓ |
| Name in Credits | - | - | ✓ |
| Merch Discount | - | - | 10% |
============================================

## 5-Tier Table Template

============================================
| Tier | Fan | Supporter | Insider | Superfan | Legend |
|------|-----|-----------|---------|----------|--------|
| Price | $2 | $5 | $10 | $20 | $50 |
| Early Access | ✓ | ✓ | ✓ | ✓ | ✓ |
| Discord Role | - | ✓ | ✓ | ✓ | ✓ |
| BTS Content | - | ✓ | ✓ | ✓ | ✓ |
| Polls | - | - | ✓ | ✓ | ✓ |
| Live Stream | - | - | ✓ | ✓ | ✓ |
| Monthly Call | - | - | - | ✓ | ✓ |
| 1-on-1 Call | - | - | - | - | ✓ |
============================================

