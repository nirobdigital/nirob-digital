# Patreon Page Bio Template

## Copy and fill in your details

============================================

# Welcome to [Your Name/Podcast Name] Patreon

Hi, I'm [Your Name] and I create [what you create - podcast/art/videos/etc].

Your support helps me [specific goal - "spend more time creating" / "upgrade equipment" / "pay editors"].

## Why become a patron?

When you subscribe, you get:

✨ **Early access** to episodes - [X] days before everyone else
🎧 **Ad-free listening** - Never hear an ad again
📸 **Behind-the-scenes** - How episodes are made
💬 **Private Discord** - Chat with me and other fans
🎁 **Monthly bonus content** - Extras you won't find anywhere else

## What your money supports

- [XX%] goes to [equipment/software]
- [XX%] goes to [editing/design]
- [XX%] goes to [time/sustainability]

## Choose your tier

**$3 Supporter** - Early access + Shoutout
**$8 Insider** - All above + BTS + Discord
**$15 Superfan** - All above + Q&A + Name in credits

## Join the community

[Link to join]

Thank you for believing in this work. I can't wait to share more with you.

— [Your Name]

============================================

