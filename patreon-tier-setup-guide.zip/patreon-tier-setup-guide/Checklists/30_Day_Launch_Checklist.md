# 30-Day Patreon Launch Checklist

## Week 1: Preparation (Days 1-7)
- [ ] Define your 3 or 5 tier structure
- [ ] List rewards for each tier
- [ ] Set prices using pricing psychology
- [ ] Create tier comparison table
- [ ] Write Patreon page bio
- [ ] Design cover image for Patreon
- [ ] Create welcome email sequence
- [ ] Set up Discord or community space

## Week 2: Pre-Launch (Days 8-14)
- [ ] Create waitlist landing page
- [ ] Announce "Patreon coming soon" on social media
- [ ] Share teaser of exclusive rewards (3 posts)
- [ ] Collect email addresses (aim for 50+)
- [ ] Create launch hype video (30 seconds)
- [ ] Set launch date (choose Tuesday)
- [ ] Prepare early bird discount (first 7 days only)

## Week 3: Launch Week (Days 15-21)
- [ ] Day 15: Post "1 week until launch"
- [ ] Day 16: Share tier comparison table
- [ ] Day 17: Unbox/create a reward sample video
- [ ] Day 18: Post FAQ about Patreon
- [ ] Day 19: 24-hour countdown
- [ ] Day 20: LAUNCH DAY - Go live at 10 AM
- [ ] Day 20: Send email to waitlist
- [ ] Day 20: Post launch announcement everywhere
- [ ] Day 21: Share first patron milestone

## Week 4: Post-Launch (Days 22-30)
- [ ] Send welcome emails to new patrons
- [ ] Post first exclusive content
- [ ] Thank each patron personally
- [ ] Ask for testimonial from early patrons
- [ ] Track conversion rate from waitlist
- [ ] Analyze which tier performed best
- [ ] Plan next month's exclusive content

## Ongoing Retention Checklist
- [ ] Weekly exclusive post minimum
- [ ] Monthly behind-the-scenes update
- [ ] Patron poll every 2 weeks
- [ ] Anniversary shoutout system
- [ ] Quarterly "thank you" bonus
- [ ] New reward added every 3 months

