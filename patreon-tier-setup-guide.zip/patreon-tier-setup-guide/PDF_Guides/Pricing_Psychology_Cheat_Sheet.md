# Pricing Psychology Cheat Sheet for Patreon Tiers

## 7 Psychological Principles That Drive Conversions

### 1. The Decoy Effect
Present 3 tiers where the middle tier is most attractive.

**Example:**
- $3 - Basic (Low value)
- $9 - Pro (BEST VALUE - decoy makes this look amazing)
- $15 - Premium (High price)

### 2. Anchoring
Show a higher price first to make your tier seem affordable.

**Example:** "Normally $20/month — Start at just $5"

### 3. Charm Pricing
Prices ending in .99 or .97 convert better than round numbers.

| Don't Use | Use Instead |
|-----------|-------------|
| $10 | $9.99 |
| $5 | $4.97 |
| $20 | $19.99 |

### 4. Scarcity
Limited spots at certain tiers.

**Example:** "Only 50 spots at this price"

### 5. Social Proof
Show how many people joined.

**Example:** "Join 1,247 other supporters"

### 6. The "Free" Effect
Adding a free tier increases paid conversions by 43%.

### 7. Loss Aversion
Frame as "Don't miss out" not "Get this benefit"

**Example:** "Lock in this price before it increases"

## Best Price Points for Patreon

| Tier Type | Price | Best For |
|-----------|-------|----------|
| Entry | $2 - $5 | Curious fans |
| Mid | $7 - $12 | Engaged community |
| Premium | $15 - $25 | Superfans |
| VIP | $30 - $100 | High-touch access |

## Price Increase Strategy
1. Announce 30 days before
2. Lock current patrons at old price for 6-12 months
3. Add new value before increasing
4. Send 3 reminders (30, 14, 7 days)

